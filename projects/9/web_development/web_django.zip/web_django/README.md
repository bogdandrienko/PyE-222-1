# PyE-222-1
study

# Для запуска проекта нужно(windows):
* Запустить файл [create_env.cmd](scripts%2Fcreate_env.cmd)
* Запустить файл [start_app.cmd](scripts%2Fstart_app.cmd)

# Для запуска проекта нужно(linux):
* Запустить файл [create_env.sh](scripts%2Fcreate_env.sh)
* Запустить файл [start_app.sh](scripts%2Fstart_app.sh)

# https://www.craft.do/s/n6OVYFVUpq0o6L