export default function Page(){
    return <div>Страница поиска</div>
}